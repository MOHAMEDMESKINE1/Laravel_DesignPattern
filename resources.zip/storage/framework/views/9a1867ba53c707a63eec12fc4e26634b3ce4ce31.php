<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="https://kit.fontawesome.com/7974ce4497.js" crossorigin="anonymous"></script>
        
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" >
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" >
     
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

     <!-- bootstrap css -->
     
     <!-- font awesome -->
     
</head>
<body class="bg-light">
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>








    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  
    <!-- bs js -->
    
    

    <!-- fontawseome js -->
    
</body>
</html><?php /**PATH C:\xampp\htdocs\PROJECTS\LARAVEL\restaurant-project\resources\views/layouts/app.blade.php ENDPATH**/ ?>