<?php

namespace App\Http\Controllers;

use App\Models\Restaurant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class RestauController extends Controller
{
    //

    public function index(){
        
        return  view("home");
    }
    public function list(){

        // $search =Restaurant::where('name','like','%'.$name.'%');

        // if ($search)
        // {
        //       return view("list",compact("search"));
        // }
        
            $restaurants = Restaurant::latest()->get();

            return view("list",compact("restaurants"));
        
       
    }
    public function store(Request $request){

      $data = $request->validate([
        "name"=> "required",
        "email"=> "required|email",
        "address"=> "required",
       ]);

       if($data){
        Restaurant::create([
            "name"=>$request->name,
            "email"=>$request->email,
            "address"=>$request->address,
           
           ]);
       }
     
       Session::flash('added','bien ajouté');
       return redirect('list');
       
      

    }
    public function edit( $id){
        $restaurant = Restaurant::find($id);
        return view("edit",compact("restaurant"));

    }
    public function update(Request $request, $id){

        $restaurant = Restaurant::find($id);
       
        $data = $request->validate([
            "name"=> "required",
            "email"=> "required|email",
            "address"=> "required",
           ]);

        if($data){

            $restaurant->update([
                "name"=>$request->name,
                "email"=>$request->email,
                "address"=>$request->address,
            ]);
    
        }
        Session::flash('updated','bien modifié');

        return \redirect('list');
      
    }
    public function destroy( $id){

      
        $restaurant = Restaurant::find($id);
        $restaurant->delete();

        Session::flash("deleted","bien supprimé");
        return redirect('list');
    }
}
